# CW2, QUESTION 3

class RoseTree:


# TEST:

# this is the output of rt when this code is run on my MAC OS termianl:
# python3 question3.py
# Part a:
# a
# b
# c
# f

# Part b:
# ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']


# a. (5 marks)
    def __init__(self, tree):
        # sets the value of self to the first element in the tree
        self.value = tree[0]
        #  sets the children of self to the children in the rosetree starting from second element in the tree
        self.children = [RoseTree(child) for child in tree[1]]

    # this function implement tree indexing, which by the use of xs (the list past in),
    #  each element in that list will indicate which child to follow in the tree. 
    # if valid the value of the node at the specified position from tree will be returned 
    # if invalid the IndexError is raised
    def __getitem__(self, xs):
        # creates a variale for the current RoseTree
        theTree = self
        # then we loop through each element in the list xs
        for i in xs:
            # here we are checking if i is a valid index for the children of theTree/current RoseTree, which we do
            # by making sure i is not a negative number and is less than the length of the children
            # if i is not valid hence the not, then the IndexError is raiased
            if not (0 <= i < len(theTree.children)):
                raise IndexError("index out of bounds")
            # otherwise the theTree is set to the current child in the tree (pointing theTree to its child at index i)
            theTree = theTree.children[i]
            #  lastly after the whole list has been traversed the value of the node that theTree now represents is returned
        return theTree.value

# b. (5 marks)

    # this function is to make the tree iterable
    def __iter__(self):
        # here I am getting the stack in order to perform the depth-first traversal, as it supports the behaviour of LIFO,
        # last in first out. The stack will help to keep track of the nodes that still need to be visited during the depth-first traversal
        
        # we are first initializing a stack, which is set to only contain the current node, whichis the root node
        self.stack = [self] 
        # then we return itself (self) as the iterator
        return self

    def __next__(self):
        # since the stack is used to keep track of any nodes still needing to be visited. If the self.stack is empty meaning
        # there are no more nodes needing to be visited then the StopIteration is raised, terminating the code
        if not self.stack:
            raise StopIteration 
        # this line retrieves the next node that needs to be processesed in the depth-first traversal, by poping the current node from the stack and assigning its value
        currentN = self.stack.pop()
        # here I am pushing all the children from the current node onto the stack but in reverse order, 
        # for it to be used later, this achieves the depth-first traversal.
        # we also reverse it to achieve the LIFO (last in first out) behavour. We then get a pre-order
        # traversal that is in a left-to-right order, which is what we want.
        # we proccess the most recently added children first to also achieve LIFO behaviour
        # we need to reverse it as well because otherwise when currentN.children is pushed onto the stack,
        # the first child (leftmost) is at the bottom of the stack, and the last child (rightmost) is at the top, which is not what we want
        # because then the rightmost child is processed before the leftmost child, achieving the right-to-left order, which
        # is an invalid depth-first traversal in this case
        self.stack.extend(reversed(currentN.children))
        # lastly the output is then the value of the current node
        return currentN.value 


rt = ('a', [ ('b', [])
           , ('c', [ ('d', [])
                   , ('e', [])
                   , ('f', [])
                   , ('g', [])
                   ])
           , ('h', [ ('i', [])
                   ])
           ]
     )


if __name__ == '__main__':
    example = RoseTree(rt)

    print("Part a:")
    print(example[[]])
    print(example[[0]])
    print(example[[1]])
    print(example[[1,2]])

    print("\nPart b:")
    print([ x for x in example ])

    # Provide further testing output and examples below.
