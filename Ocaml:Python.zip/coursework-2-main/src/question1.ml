(* CW2, QUESTION 1 *)


(* -------------------------------------------------------TESTS------------------------------------------------------------------------------------------- *)

(* a) *)

(* I added print statments in my isvalidSeq to see what the variables held: *)
(*
  utop # isValidSeq (3,4) [(4,5); (6,5); (7,2)] [NE; NW];;
      Current position: 3,4
      Move: NE
      New position: 5,6 (+2 is added to both x and y, to achieve NE)
      Intermediate position: 4,5
      New pos occupied: false, Opposite pos occupied: true
      Current position: 5,6
      Move: NW
      New position: 7,4
      Intermediate position: 6,5
      New pos occupied: false, Opposite pos occupied: true
      Base case reached.
      Remaining pieces: (7,2)
      Other moves possible: false
      - : bool = true 

      (returns true as all moves are possible regardless of if there 
       are other pices on the board, as long as they cant be captured 
      true would still be returned)
*)
(* 
  utop # isValidSeq (3,4) [(4,5); (6,5)] [NE];;
      Current position: 3,4
      Move: NE
      New position: 5,6
      Intermediate position: 4,5
      New pos occupied: false, Opposite pos occupied: true
      Base case reached.
      Remaining pieces: (6,5)
      Other moves possible: true
      - : bool = false 

      (false is returned as even though the move passed in was valid, the 
       second opponents piece could still be captured, as othermoves returns 
       true the main function would return false, as if there are still othermoves 
       to be made after checking all the moves the user provided the isValidSeq 
       would return false as it did here)
 *)

 (* b) *)

 (* 
 utop # allMoves (3,3) [(4,4); (6,4); (6,6); (4,6)];;
- : move list list = [[NE; SE]; [NE; NW]; [NE; NE]]

(this returns the right moves as there are three possible moves to be made)
 *)

 (* 
 utop # allMoves (3,3) [(4,4); (5,5)];;
- : move list list = []

(this returns an empty list as there are no moves to be made, as the users position can't go to (5,5) as it's occupied)
 *)



(* ------------------------------------------------------------------------------------------------------------------------------------------------------- *)


type pos = int * int
type move = NE | NW | SE | SW

(* Helper function to map a list *)
 let rec map f xs =
    match xs with
    | [] -> []
    | x :: xs -> f x :: map f xs;;

(* helper function to check if a position that is trying to be made has been taken *)
let rec isposfull posilist posi =
  match posilist with
  | [] -> false
  | h :: t -> if h = posi then true else isposfull t posi

(* helper function to remove the position that has been captured from the list *)
let rec removePos posLi positi =
  match posLi with
  | [] -> []
  | h :: t -> 
      if h = positi then removePos t positi
      else h :: removePos t positi

      (* this checks to see if coordinates passed in are on the board which is 8^8 *)
      let onBoard (a, b) = a > 0 && b > 0 && b <= 8 && a <= 8

(* this function moves the users piece according to the move passed in, it always jumps diagonally *)
let changepos (x, y) move =
  match move with
  | NE -> if onBoard (x + 2, y + 2) then (x + 2, y + 2) else failwith "Not on the board"
  | NW -> if onBoard (x + 2, y - 2) then (x + 2, y - 2) else failwith "Not on the board"
  | SE -> if onBoard (x - 2, y + 2) then (x - 2, y + 2) else failwith "Not on the board"
  | SW -> if onBoard (x - 2, y - 2) then (x - 2, y - 2) else failwith "Not on the board"


  (* this function is used to check if the opponent has a piece diagonally that the user can capture, it has the same functionality
    as changepos just that we move diagonally without jumping over as changepos does. Once we store the diagonally position we can then
      check if there is a piece on the space using isposfull *)
let oppPos (x, y) move =
  match move with
  | NE -> if onBoard (x + 1, y + 1) then (x + 1, y + 1) else failwith "Not on the board"
  | NW -> if onBoard (x + 1, y - 1) then (x + 1, y - 1) else failwith "Not on the board"
  | SE -> if onBoard (x - 1, y + 1) then (x - 1, y + 1) else failwith "Not on the board"
  | SW -> if onBoard (x - 1, y - 1) then (x - 1, y - 1) else failwith "Not on the board"

 
(* this function checks if other moves are possible that the user can make, will be called when the users move list is empty, 
  which also means when the users moves are all done the code will check if other moves are possible *)
  let rec otherMoves moveL poslist pos =
    match moveL with
    (* when the list of moves are empty, also meaning all the other possible moves has been tried, therefore return false
    as there are no othermoves that could be made*)
    | [] -> false 
    | h :: t ->
      (* new_pos will be set to changepos with the position passed in and current h, this is in a 
      try block as if the position passed in is (7,4) the user could not move NE or NW as it would 
      result in out of bounds failwith, whereas SW and SE would work, therefore a try has been 
      used to try with the move passed in. The positions are set to -1 as to show that the move 
      was invalid to make. This is the same for opposite_pos *)
        let new_pos = try changepos pos h with Failure _ -> (-1, -1) in
        let opposite_pos = try oppPos pos h with Failure _ -> (-1, -1) in
        (* then it checks if both new_pos and opposite_pos is onBoard and if not 
         the code would move on with the next move as there is no point in continuing 
        the function if the move makes the piece move out of the board *)
        if not (onBoard new_pos) && not (onBoard opposite_pos) then
          otherMoves t poslist pos
        else
          (* otherwise if the new_pos and opposite_pos is both on the board the code would then
            proceed to check if the new_pos is occupied and aslo checking if the opposite_pos is occupied 
            and if the new_pos is full then we move onto the next move as there is no point
            in checking if there is an opponent to be captured as we can't make the move in the first place. *)
          let check_new_pos = isposfull poslist new_pos in
          let check_opposite_pos = isposfull poslist opposite_pos in
          if check_new_pos then
            otherMoves t poslist pos
            (* otherwise if both new_pos and opposite_pos are on the board and the new_pos is not taken and 
            also the opposite_pos is taken by the opponent, then we return true as a move was able to be made,
             and there is no point in checking the rest of the moves as we only need one valid move to show that 
             other moves are able to be made. *)
          else if check_opposite_pos && check_new_pos = false then true
          else
            (* otherwise if the opposite_pos is not full meaning there is no piece to be captured then 
            there is no move that can be made therefore the code continues with the rest of the moves
           as this one was invalid *)
            otherMoves t poslist pos

(* isValidSeq : pos -> pos list -> move list -> bool *)
(* this main function is to validate the sequence of moves *)
let rec isValidSeq (p : pos) (ps : pos list) ms =
  match ms with
  | [] ->
      (* if no moves are left or no moves were passed in then it checks if the position list 
        is empty (if no more pieces are to be captured, meaning they have all been captured 
      ( all pieces don't need to be captured for the sequence of moves to be valid )),
      if the pos list is empty then true is returned as all pieces would have been captured or
      there were no pieces to be captured in the begining (if pos list was input as []), and that 
      would make a valid sequence.
      But if the pos list is not empty then the otherMoves function will be called with an if statement and the positon list
     (which would not be empty), the positon and the moves of moving NE, NW, SE, SW all gets passed into otherMoves 
      The if statement says that if otherMoves returns true with those inputs meaning there still are
         othermoves to be made then false should be returned for isValidSeq as there were still other movves 
      that could have been made, in order to catch more pieces. And since does moves werent in the moves
      list passed in at the start, the code would return false. 
      Otherwise if there were no other moves that could be made then the sequence of moves passed in is valid and true would be returned *)
      
        if ps = [] then true
      else if otherMoves [NE; NW; SE; SW] ps p then false
      else true
  | h :: t ->
    (* then we are going through the list of moves and trying the following steps: *)
      try
        (* firstly we create a new position that will try to make pos make the move that we are currently on (h) *)
        let newPos = changepos p h in
        (* then we make op that will move an imaginery pos to the h move -1, as newPos will be jumping diagonally
          op would be moving straightly diagonally without jumping over as newPos does, this will help us to verify if
         there is a piece that can be captured *)
        let op = oppPos p h in
        (* we then check the new pos, to see if there is already a piece on the space that the newPos is trying to jump to *)
        let check_new_pos = isposfull ps newPos in
        (* we do the same with the op, so we check if there is already a piece there, if there is then 
          that's great as that piece can then be captured! *)
        let check_opposite_pos = isposfull ps op in
        (* if the space that newPos is trying to move to is already occupied by a piece, then false is returned
          as that move is invalid because it is already occupied, therefore there is no need in checking if op is occupied
          as no piece can be captured with this move, making the sequence of moves invalid *)
        if check_new_pos then false
          (* but if the space that newPos was trying to move to is not occupied and is able to land on that space,
             then we can go ahead and check the move that op tried to make. If the op move was invalid, because there 
             already was a piece on that space means that there is a piece that we can capture, and which has been capture by
           creating updated_ps which will store the new pos list, and updated_ps uses removePos to remove the position op is
          on to indicate that that piece has been captured, therefore that position is gone from the list and isValidSeq is
          recursively called with the updated pos list and the newPos to start the next move from the new position 
          (so we are moving forward on the board, and not staying at the initial position) *)
        else if check_opposite_pos then
          let updated_ps = removePos ps op in
          isValidSeq newPos updated_ps t
          (* but if there the move that op tried to make returned false, indicating that the move was able to be made, also indicating
            that there is no piece on the space (hence why the move was able to be made) then false would be returned as the move that pos
          made would be invalid because there was no piece captured in return of that move. *)
        else
          false
          (* and if an exception of type Failure is raised, such as a move made causing a piece to land outside the board,
             the pattern Failure _ would match it, ignoring the string payload. And false would be returned as the move would 
             be invalid to make *)
      with Failure _ -> false


(* b (6 marks) *)

(* allMoves : pos -> pos list -> move list list *)

let rec allMoves (p : pos) (ps : pos list) =
  (* First I am creating a list that holds all the possible moves we can try per recursive call *)
  let moveList = [NE; NW; SE; SW] in
  (* then I make a new nested function that takes in the list that was previously defined, as well as an accumulator *)
  let rec checkMoves moves acc =
    (*  then going through each move one by one *)
    match moves with
    (* if the moves passed in are empty then return all the accumulated valid moves sequence *)
    | [] -> acc  
    | x :: xs ->
        try
          (* then we try to change the pos of the initial position passed in, but also change the
           opposite position, so that we can determine if the spots are taken or not. A try block
           is used as one or more moves can result in a out of border failwith. *)
          let newP = changepos p x in
          let op = oppPos p x in
          if 
            (* if the new position is on the board and the position that it wants to jump to/ the new
               position isn't occupied, and the space where we are trying to capture a piece is occupied
               (actually has a piece to be captured) then remove the captured piece from the list of 
               opponent positions, to indicate it has been captured *)
            onBoard newP &&           
            not (isposfull ps newP) && 
            isposfull ps op          
          then
            let updated_ps = removePos ps op in
            (* then since a piece has been captured, we then recursively 
            call the method again but with the updated position and list *)
            let furtherMoves = allMoves newP updated_ps in
            (* then if no further moves are possible then only this current move is possible *)
            let validMoves = 
              if furtherMoves = [] then [[x]]
                (* otherwise map through the moves and add this current move onto the list of outputs *)
              else map (fun mov -> x :: mov) furtherMoves
            in
            (* then recursively call checkmoves with the validMoves list appended unto the accumulator list *)
            checkMoves xs (validMoves @ acc)
          else
            (* otherwise call checkmoves again with the remaining list of moves and the accumulator list *)
            checkMoves xs acc 
            (* but if the current move results in a out of board failwith, then 
              call checkmoves again with the remaining list of moves and the accumulator list *)
        with Failure _ -> checkMoves xs acc
  in
  (* all of this in checkmoves, with the list of moves (moveList) and the empty list passed in *)
  checkMoves moveList [] 