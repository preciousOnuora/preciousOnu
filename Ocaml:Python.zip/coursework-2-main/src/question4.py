# CW2, QUESTION 4


# TEST:

# this is the output when this code is run on my MAC OS termianl:
""" 
python3 question4.py

    [3, 1, 4, 2]
    [1, 2, 0]
    [3, 1, 2, 4] 

"""
# and they all have the expected output whichnis good :)






# a. (5 marks)

# this function computes the next lexicographic permutation of a list that is input,
# if the list is already the last permutation, None would be returned.
def next_permutation(xs):
    # n is set to the total length of the list passed in
    n = len(xs)
    
    # k is set to n - 2, meaning the index of k would be the second to the last element in the list,
    #  which will later be used to find the largest index in the list
    k = n - 2

    # this while loop looks for the largest index in the list, meaning the sequence at and after k are all in descending order
    # the loop starts at k (the second to last element) and moves to the left, hence the -1
    # if moving to the left becomes invalid (no element there), also meaning the list is in descending order
    # then the loop terminates with k = -1
    while k >= 0 and xs[k] >= xs[k + 1]:
        k -= 1

    # if k < 0 means that the list is the last permutation, therefore no next permutation exists and None is returned
    if k < 0:
        return None
    
    # this finds the largest index for l where xs[k] < xs[l]
    # firstly we set l to be the last index in the list
    # then we are moving l to the left until a valid l is found
    l = n - 1
    while xs[k] >= xs[l]:
        l -= 1
    
    # then we swap the values at xs[l] and xs[k], this is to make sure that the next permutation is greater than the current one
    xs[k], xs[l] = xs[l], xs[k]
    
    # this reverses the order of all the elements from xs[k+1] to the end of the list
    # this is done because after the swap, the subarray [k+1:] is still in descending order
    # this would make us get the smallest possible order, therefore resulting in the next smallest permutation
    xs[k + 1:] = reversed(xs[k + 1:])
    
    # lastly we return the modified list that was passed in, which is now the next permutation
    return xs

# this is a helper function which computes the factorial of n passed in,
#  this will be used in part b to efficiently get the nth permutation
def factorial(n):
    # result is set to 1 (comulative product)
    result = 1
    # this steps through each i in the range from 1 to n (inclusive), multiplying the result by i
    for i in range(1, n + 1):
        result *= i
    # then once the loop is done, result is returned which contains the factorial of n
    return result


# b. (5 marks)

def nth_permutation(xs, n):
    # result is created to store the elements of the resulting permutaion, which will later be returned
    result = []
    # this while loop will continue until the list xs has no more elements inside
    while xs:
        # m is set to the total length of the list passed in, 
        # which will be used to calculate the number of remining elements in the list
        m = len(xs)
        # fact computes (m-1)!, which represents the number of permutations for each block starting with a given element
        fact = factorial(m - 1)
        # n // fact determines how many full blocks of size (m-1)! fit into n which will then be set to variable index
        # (determines the index of the next element)
        index = n // fact 
        # using xs.pop(index) removes the element at index from xs and returns it, the returned element is then appended onto result,
        # which adds the selected element to the result list
        result.append(xs.pop(index)) 
        # n is then updated to be the remainder when n is divided by fact, which updates n for the next iteration
        n %= fact 
    # then lastly after the while loop has been complete, meaning after the list passed in has been emptied
    #  and gone through fully we return result which contains the nth permutation
    return result


if __name__ == '__main__':
    print(next_permutation([3,1,2,4]))    # [3,1,4,2]
    print(nth_permutation([0,1,2], 3))    # [1,2,0]
    print(nth_permutation([1,2,3,4], 12)) # [3,1,2,4]
