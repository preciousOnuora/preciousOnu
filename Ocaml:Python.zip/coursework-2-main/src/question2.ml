
(** CW2, QUESTION 2 **)
exception UndefinedVariable of string


(* -------------------------------------------------------TESTS------------------------------------------------------------------------------------------- *)

(* 
allEnvs ["x"; "y"];;
- : env list =
[[("x", true); ("y", true)]; [("x", true); ("y", false)];
 [("x", false); ("y", true)]; [("x", false); ("y", false)]] 
 *)

 (*  varsOf (And (Var "x", Not (Or (Var "y", Var "x"))));;
- : string list = ["x"; "y"]
 *)

 (* 
 simplify True [];;
- : bexp = True
 *)

 (* 
(simplify (Var "x") [("x", true)] = True);;

(simplify (Var "x") [("x", true)]);;
- : bexp = True

---gives expected output
  *)

(* ------------------------------------------------------------------------------------------------------------------------------------------------- *)

(* a (2 marks) *)
type bexp =
  | False               
  | True
  | Var of string
  | Not of bexp     
  | And of bexp * bexp 
  | Or of bexp * bexp
  
type env = (string * bool) list
  
let rec forWholeList predicate lst =
  match lst with
  (* if the list is empty then the predicate is satisifed so true would be returned *)
  | [] -> true 
  (* this checks if the predicate holds for the first element and recursively for the rest of the list. *)
  | x :: xs -> predicate x && forWholeList predicate xs

(* Helper function to flatten a list *)
let rec flatten lst =
  match lst with
   (* this appends the first element of the list with the flattened rest of the list *)
  | x :: xs -> x @ flatten xs 
  | [] -> []  


(* Helper function to map a list *)
 let rec map ys xs =
    match xs with
    | [] -> []
    (* this gets the first list and the first element of the second list and adding
     the element onto the second list, slowly mapping the second list onto the first *)
    | x :: xs -> ys x :: map ys xs;;

  
(* Helper function to find a variable in the environment manually *)
let rec lookup (key : string) (environment : env) =
  match environment with
  (* if the key is not found in the environment then the undefindevariable exception is raised *)
  | [] -> raise (UndefinedVariable key)
  | (k, v) :: rest ->
    (* this returns the boolean value if the key matches the current environment pair *)
    if k = key then v
      (* otherwise recursively search the rest of the environments *)
      else lookup key rest 
    
(* Helper function to sort a list *)
let rec insert_sorted compare x lst =
  match lst with
  | [] -> [x]
  | h :: t ->
    (* if x equals h then return the list unchanged *)
    if compare x h = 0 then lst  
      (* otherwise if x is less than h then add x to the list *)
    else if compare x h < 0 then x :: lst
      (* else add h recursively to x and the rest of the list with compare *)
    else h :: insert_sorted compare x t
          
(* Helper function to sort a list uniquely *)
let rec sort_uniq compare lst =
  match lst with
  | [] -> []
  (* using insert_sorted and sort_uniq the list removes duplicates and sorts it uniqully *)
  | x :: xs -> insert_sorted compare x (sort_uniq compare xs)
  
(* Helper function to remove duplicates *)
let rec remove_duplicate compare xs = 
  (* this sorts the list before removing the duplicates and then goes through the sorted list *)
  let sorted = sort_uniq compare xs in
  match sorted with 
  | [] -> []
  (* if there is only one element then that should be returned *)
  | [x] -> [x]
  (* if the first two elements equal each other then continue on with one of the two and the rest of the list *)
  | h :: t :: ts -> if h = t then remove_duplicate compare (t :: ts)
    (* otherwise add the first element onto the recursive call and continue  *)
  else h :: remove_duplicate compare (t :: ts)
    
                 
                
(* b (3 marks) *)
              
(* eval : bexp -> env -> bool *)
(* this function is to compute a value of a logical expression with
 a given environment that provides interpretations for variables.*)
let rec eval (expression : bexp) (environment : env) =
  match expression with
  | False -> false
  | True -> true
  (* this evaluates a variable by looking up its value in the environment *)
  | Var x -> lookup x environment
  (* this evaluates the negation if that is the expression passed in *)
  | Not e -> not (eval e environment) 
  (* the two lines below evaluates the expressions, wheter it is an And or Or passed in *)
  | And (e1, e2) -> (eval e1 environment) && (eval e2 environment)  
  | Or (e1, e2) -> (eval e1 environment) || (eval e2 environment)  

  
(* c (4 marks) *)
(* varsOf : bexp -> string list *)
(* this function extracts a list of all variable names present in the given boolean expression, removing duplicates as well *)
let rec varsOf (expr : bexp) = 
  (* firstly we are removing any duplicates in the list of variable names *)
  let remove_dup xs =
    remove_duplicate compare xs in
  match expr with 
  (* since true and false are not variables, the empty list is returned *)
  | True -> []
  | False -> []
  (* if the expression is a variable then it returns its name as a singleton list *)
  | Var x -> [x]
  (* for negation, recursively extract variables from the inner expression *)
  | Not e -> varsOf e
  (* if it is an And or Or then the first element of the tuple will 
    be recursively called as the expression and then appended onto 
  the second element of the tuple being recursively called as well, but this time it calls remove_dup *)
  | And (e1, e2) -> remove_dup (varsOf e1 @ varsOf e2)
  | Or (e1, e2) -> remove_dup (varsOf e1 @ varsOf e2)
  
  (* d (4 marks) *)
(* allEnvs : string list -> env list *)
(* this function finds all the possible environments that give interpretations to variables on a given list *)
(* I added : env list  to get "env list" as the return type instead of (string * bool) list list, which is essentially the same thing *)
let rec allEnvs (lst : string list) : env list = 
  (* it starts of with removing all duplicates from the input list of variable names*)
  let remove_dupl =
    remove_duplicate compare lst in
    (* it goes through the list with no duplicates *)
  match remove_dupl with 
  | [] -> [[]]
  | h :: t -> 
    (* this recursively computes all possible environments for the rest of the variables using t and then stores it in envs *)
    (* using map (h, true) is added to the start of each environment in envs,
       this is for all the environments wehre the current variable h is assigned the value true *)
       (* then the same is for (h, false) just that it is where the current variable h is assigned the value false *)
       (* then using [] to combine the two list of environments, one for true and one for false.
        Which is then passed into flatten, which then merges the two lists containing all possible environments for h *)
    let envs = allEnvs t in
    flatten
     [ 
      map (fun env -> (h, true) :: env) envs;
      map (fun env -> (h, false) :: env) envs 
      ]
  
      
(* e (2 marks) *)
(* isAlwaysTrue : bexp -> bool *)
let isAlwaysTrue exp = 
  (* first it extracts all variables from the expression using varsOf *)
    let vars = varsOf exp in
    (* then using all the variables the code generates all environments possible using the function allEnvs *)
    let allEnvs = allEnvs vars in
    (* lastly we go through the whole list checking if the expressions results to true in all possible environments of its vaiables *)
    forWholeList (fun env -> eval exp env) allEnvs
      
(* f (5 marks) *)
(* simplify : bexp -> env -> bexp *)

let rec simplify expr env =
  match expr with
  (* if true or false the expression will be returned *)
  | True | False -> expr  
  | Var x -> 
    (
      (* if the expression is a variable then the code will try to lookup the variable
         and replace the variable with its value from the corresponding environment *)
        try
        (* if the variable is found, it is replaced with True or False based on its value in the environment *)
        if lookup x env then True else False
        (* if the variable is not found then the exception UndefinedVariable is caught and the variable Var x gets left as it is *)
      with UndefinedVariable _ ->
        Var x  
    )
  | Not e -> 
    (
      (* we need to match simplify with the variable that was passed in to be negated, then we go through the options of negations *)
      match simplify e env with
      (* if True is negated, the output would be false, as it is the opposite *)
      | True -> False 
      (* same with false, if false is negated the output would be true *)
      | False -> True
      (* if it's a variable then the negation of it self is it's self *)
      | e' -> Not e'
    )
  | And (e1, e2) -> 
    (
      match (simplify e1 env, simplify e2 env) with
      (* false AND anything simplifies to false *)
      | (False, _) | (_, False) -> False
      (* true AND any expression simplifies to the expression *)
      | (True, ex) | (ex, True) -> ex 
      (* otherwise keep it as it is *)
      | (e1', e2') -> And (e1', e2') 
    )
  | Or (e1, e2) -> 
    (
      match (simplify e1 env, simplify e2 env) with
      (* true OR anything simplifies to true *)
      | (True, _) | (_, True) -> True 
      (* false OR any expression simplifies to the expression *)
      | (False, ex) | (ex, False) -> ex 
      (* else return it self, keep it as it is *)
      | (e1', e2') -> Or (e1', e2')
    )


