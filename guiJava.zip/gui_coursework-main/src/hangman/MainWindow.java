package hangman;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JFrame;

public class MainWindow extends JFrame {

	ArrayList <String> list = new ArrayList<String>();
	public String word;

	// MainWindow where all the panels are called
	public MainWindow() 
	{
		// I have implemented the readFile outside of the constructor to achieve low coupling
		readFile();

		// the mainwindow is passed into all the panels
		WordPanel wp = new WordPanel(this);
		HealthPanel hp = new HealthPanel(this);

		// since the ButtonPanel is where the actionPerformed is, I decided to pass all the panels and the mainwindow into the ButtonPanel, so that it can access everything
		ButtonPanel bp = new ButtonPanel(this, wp, hp);
		hp.CreatingHealthPanel();

		// sets up the frame
		Container cpane = getContentPane();
		setSize(1000,800);
		setTitle("Hangman");

		// I used this layout so that all panels would have the same size efficiently
		setLayout(new GridLayout(3,1));

		cpane.setBackground(Color.gray);
		cpane.add(hp);
		cpane.add(bp);
		cpane.add(wp);
	}

	// this method generates a random word from the file called text.txt
	public void readFile() 
	{
		try {
			// reads in the file
			BufferedReader in = new BufferedReader(new FileReader("text.txt"));
			String s = null;
			while ((s = in.readLine())!= null)
			{
				list.add(s);
			}

			// gets a random word
			int length = list.size();
			int index = (int) (Math.random() * length);
			word = list.get(index);

		}
		catch (IOException e)
		{
			System.out.println("A error has occured");
		}
	}
}