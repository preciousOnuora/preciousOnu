package hangman;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Run {

	public static void main(String[] args) {
		MainWindow mw = new MainWindow();
		// this method is a JFame method and it takes in a WindowAdapter which will display a open message when game is opened and a closing message when the exit button is clicked
		mw.addWindowListener(new WindowAdapter() 
		{
			public void windowClosing(WindowEvent e) 
			{
				System.out.println("Window closing");
				System.exit(0);
			}
			public void windowOpened(WindowEvent e) 
			{
				System.out.println("Window opened, welcome");
			}
		});

		// this sets the frame to be visible
		mw.setVisible(true);
	}

}
