package hangman;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class WordPanel extends JPanel {

	String[] jbutton;
	JButton[] jb;
	JLabel[] labels;

	private String guess_word;
	private int lengthOfWord;
	private int success;

	MainWindow mainw;
	HealthPanel healthp;

	Font f = new Font("Helvetica", Font.PLAIN, 20);


	// this conctructor generates a number of underscores according to the random word
	public WordPanel(MainWindow mw) 
	{
		this.mainw = mw;

		// gets the random word from mainWindow
		guess_word = mainw.word;

		setBackground(Color.gray);
		lengthOfWord = guess_word.length();

		labels = new JLabel[lengthOfWord];

		// creates labels represented as underscores for the amount needed for the random word
		for (int i = 0; i< labels.length; i++)
		{
			labels[i] = new JLabel("_");
			labels[i].setFont(f);
			labels[i].setBounds(50, 50, 50, 50);
			add(labels[i]);
		}
	}

	// this method is called whenever a guess is made, it checks if the letter pressed matches any letter of the word to be guessed
	public int guess (String letter) 
	{

		// if success stays 0 then the guess was wrong/false
		success = 0;

		// this for loop goes through each letter of the word and checks if the letter that was passed in is a match
		for (int i = 0; i < labels.length; i++)
		{
			// if the letter that was guessed is in the secret word then the letter will be revealed at the right places
			if (guess_word.charAt(i) == letter.charAt(0)) 
			{
				labels[i].setText(letter);

				// success is being incremented everytime a guess is wright to make sure the right message is output at the end of the game
				success ++;
			}
		}
		return success;

	}

	// this method is called whenever the user wants to restart the game, a new word is generated with the corresponding underscores
	public void resetWordP() 
	{

		for (int i = 0; i< labels.length; i++)
		{
			// I added this to ensure that the old labels are removed
			remove(labels[i]);	
		}

		setBackground(Color.gray);

		// this gets a new random word from the text file
		mainw.readFile();

		// this gets the word from the mainWindow
		guess_word = mainw.word;
		lengthOfWord = guess_word.length();

		// sets the array of labels to be the length/size of the new random word
		labels = new JLabel[lengthOfWord];

		for (int i = 0; i< labels.length; i++)
		{
			labels[i] = new JLabel("_");
			labels[i].setFont(f);
			labels[i].setBounds(50, 50, 50, 50);
			add(labels[i]);
		}

		// these adds the new labels to the panel
		revalidate();
		repaint();
	}

}
