package hangman;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class HealthPanel extends JPanel
{

	public int lives = 0;
	public int count = 0;
	private JLabel[] jlabel;

	MainWindow mainWindow;

	public HealthPanel(MainWindow main) {

		// setting this 'mainWindow' to the MainWindow that was passed in
		this.mainWindow = main;
	}


	public void CreatingHealthPanel() 
	{
		jlabel = new JLabel[7];
		setBackground(Color.gray);
		setLayout(new GridLayout(1,7));

		// creates each jlabel
		for (int i = 0; i<7; i++)
		{
			jlabel[i] = new JLabel("" + (i+1));
			jlabel[i].setBackground(Color.green);
			jlabel[i].setOpaque(true);
			add(jlabel[i]);
		}
	}

	// this method is called whenever a wrong guess is made, it turns one of the labels red each time to indicate one life is lost
	public int removeLife(int lives) 
	{	
		if (lives >= 0 && lives <= 7) 
		{
			jlabel[lives].setOpaque(true);
			jlabel[lives].setBackground(Color.red);
			count++;
		}
		return lives;
	}

	// this method is called whenever the user would like to restart the game, it sets all the labels/lives back to green
	public void resetHealth() 
	{
		setBackground(Color.gray);
		setLayout(new GridLayout(1,7));

		for (int i = 0; i<7; i++)
		{
			jlabel[i].setBackground(Color.green);
			jlabel[i].setOpaque(true);
			add(jlabel[i]);
		}
	}

}
