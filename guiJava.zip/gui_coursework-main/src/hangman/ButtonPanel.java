package hangman;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class ButtonPanel extends JPanel implements ActionListener {

	String[] jbutton;
	JButton[] jb;

	private String letter;
	private int life;
	private int guessMethod;
	private int counter;

	JFrame f = new JFrame();
	JOptionPane dialog = new JOptionPane();

	MainWindow main;
	HealthPanel health;
	WordPanel wordp;

	public ButtonPanel(MainWindow mw, WordPanel wp, HealthPanel hp) 

	{
		this.wordp = wp;
		this.main = mw;
		this.health = hp;

		setBackground(Color.gray);

		jbutton = new String[] {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};
		jb = new JButton[26];

		setLayout(new GridLayout(2,13));

		// iterates through each letter and creates a button for that letter
		for (int i =0 ; i<26 ; i++) 
		{

			jb[i] = new JButton(jbutton[i]);
			jb[i].setBackground(Color.gray);
			jb[i].setOpaque(true);
			add(jb[i]);
			// a actionlistener is added to each button so that they can be clicked
			jb[i].addActionListener(this);
		}

	}

	// this method is called whenever the user restart the game, all the buttons that were clicked and disabled go back to being enabled and ready to use again
	public void resetButtons() 
	{	
		setLayout(new GridLayout(2,13));
		//counter = 0;
		for (int i =0 ; i<26 ; i++) 
		{
			jb[i].setBackground(Color.gray);
			jb[i].setEnabled(true);
			setOpaque(true);
			add(jb[i]);
		}
	}

	// this is the action method where most of the methods will be called from
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		// iterates through each letter 
		for (int i = 0; i < 26; i++) 
		{
			// checks if the letter that has been clicked matches the letter that i is on
			if (e.getSource() == jb[i])
			{
				// once the letter has been found it is set to a variable
				letter = jbutton[i];

				guessMethod = wordp.guess(letter);
				jb[i].setEnabled(false);

				// if the guess was wrong then the removeLife is called and life is incremented
				if (guessMethod == 0) 
				{
					health.removeLife(life);

					// keeps track of the number of lifes the user has 
					life ++;

					// if the user has used all their lifes then a lost message is output using a dialog box
					if (health.count >= 7) {
						dialog.showConfirmDialog(f,"You lost!" + "The word to be guessed was: " + main.word , "Game Over Message", dialog.PLAIN_MESSAGE);
						int answer = dialog.showConfirmDialog(f,"Restart?", "Restart", dialog.YES_NO_OPTION);

						// if the user clicks yes, to restart, then all the reset methods are called and the game resets with a new word
						if (answer == dialog.YES_OPTION) 
						{
							health.resetHealth();
							wordp.resetWordP();
							resetButtons();

							// life and count are both set to 0 as to start from the beginnig
							life = 0;
							health.count = 0;
						}
						else {
							// if the user dosent want to restart the game, a goodbye dialog message is output and the system exits
							dialog.showConfirmDialog(f,"Goodbye", "Goodbye", dialog.PLAIN_MESSAGE);
							System.out.println("User has exit");
							System.exit(0);
						}
					}
				}
				else 
					// counter is updated if the user guessed wright
					counter += guessMethod;

				// if the user guesses the whole word writh and hasnt run out of lifes then a winnig message is output using a dialog box
				if (counter == ((main.word).length()))
				{
					System.out.println(counter);
					int correctAnswer = dialog.showConfirmDialog(f,"You won! Would you like to try again?", "Winnig message",dialog.YES_NO_OPTION);
					// game restarts if yes is clicked and the variables are set to 0
					if (correctAnswer == dialog.YES_OPTION) 
					{
						health.resetHealth();
						wordp.resetWordP();
						resetButtons();
						counter = 0;
						life = 0;
						health.count = 0;
					}
					else 
					{
						// otherwise system exits
						dialog.showConfirmDialog(f,"Goodbye", "Goodbye", dialog.PLAIN_MESSAGE);
						System.out.println("User has exit");
						System.exit(0);
					}
				}
			}


		}

	}


}
