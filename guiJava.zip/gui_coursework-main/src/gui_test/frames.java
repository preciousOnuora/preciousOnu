package gui_test;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class frames {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		JFrame frame = new JFrame();
		JPanel panel = new JPanel();
		JLabel label = new JLabel();
		
		Container cpane = frame.getContentPane();
		
		frame.setSize(1200, 700);
		cpane.setLayout(new GridLayout(3,1));
		cpane.setBackground(Color.orange);
//		cpane.setOpaque(true);
		
		JPanel jpanel = new JPanel(new GridLayout(1,8));
		jpanel.setBackground(Color.pink);
		jpanel.setOpaque(true);
		
		JLabel[] jlabel = new JLabel[8];
		for (int i=0; i< 8; i++) {
			jlabel[i] = new JLabel("" + i, JLabel.CENTER);
			jlabel[i].setBackground(Color.blue);
			jlabel[i].setOpaque(true);
			jpanel.add(jlabel[i]);
			cpane.add(jlabel[i]);

		}
			
frame.setVisible(true);
	}

}
