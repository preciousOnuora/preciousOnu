
public interface TrieADT {
	public void insert(String s);
	public boolean search(String s);
	public void delete(String s);
	public int countAllWords();
}