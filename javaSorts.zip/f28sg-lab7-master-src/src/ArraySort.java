import java.util.ArrayList;
import java.util.Iterator;

public class ArraySort {

	/** Insertion sort of an array
	 * @param arr the array to be sorted in-place
	 */
	public static void insertionSort(int[] arr) {
		for (int i = 1; i < arr.length; i++) {
			int cur = arr[i];
			int j = i - 1;
			while (j >= 0 && arr[j] > cur) {
				arr[j + 1] = arr[j--];
				arr[j + 1] = cur;
			}
		}
	}

	/** Insertion sort of an array
	 * 
	 * This is Question 3
	 * 
	 * TODO Where N is the number of elements in the array 'arr' the complexity is:
	 *
	 * O(N^2)
	 * 
	 * Because: We have to pass through the array as many times as there are pairs in the array
	 * This method sorts an array by swapping with the element next to it if greater than.
	 * @param arr the array to be sorted in-place
	 */
	public static void bubbleSort(int[] arr) { 
		// swaps is set to true initially, thinking the array is sorted
		boolean swaps = true;
		// temporary int
		int temp = 0;
		while (swaps) {
			swaps = false;
			for (int i = 0; i < arr.length-1; i++) {
				// if the element next to the current one is greater than the next element then they have to swap
				if (arr[i] > arr[i+1]) {
					// the current element is set to the temporary int so we don't loose the value of the element
					temp = arr[i];
					// the next element is set to the current element
					arr[i] = arr[i+1];
					// then the next element is set to the temporary holder, which holds the value of the current element before it was changed to the next element.
					arr[i+1] = temp;
					// swaps is set to true, as we have done a swap
					swaps = true;
				}
			}
		}

	}

	/** Quick sort of an array. This method creates a new array with
	 * its values sorted, based on the values in the unsorted input array S.
	 * 
	 * This is Question 5
	 * 
	 * TODO Where N is the number of elements in the array 'S' the complexity is:
	 *
	 * O(N^2)
	 * 
	 * Because: As the algorithm has to go through each of the n elements in each of the n steps.
	 * 
	 * @param S the unsorted input array
	 * @return the sorted output array
	 */
	public static ArrayList<Integer> quickSort(ArrayList<Integer> S) {
		if (S.size() <= 1)
			return S;
		int pivot = S.getFirst();
		// I am making 3 new arraylists 
		ArrayList<Integer> L = new ArrayList<>();

		ArrayList<Integer> E = new ArrayList<>();

		ArrayList<Integer> G = new ArrayList<>();

		// then assigning each list with the right elements
		while (!S.isEmpty()) {
			// getting the first element
			int first = S.getFirst();
			// adding the first element to the right list
			if (first > pivot)
				G.add(first);
			else if (first < pivot)
				L.add(first);
			else
				E.add(first);
		// Then removing the first element, which then updates the list
			// then when the getfirst is called again it would be the next element in the list and so forth, cutting the list shorter and shorter
			S.removeFirst();
		} 
		
		// this is making a new arraylist that are recursively called with the lists previously defined.
		ArrayList<Integer> sortedL = quickSort(L);
		
		ArrayList<Integer> sortedG = quickSort(G);
		
		ArrayList<Integer> l = new ArrayList<Integer>();
		
		// then the lists are added to the new list l.
		l.addAll(sortedL);
		l.addAll(E);
		l.addAll(sortedG);
		
		return l;
	}

	
	/** predicate to check if array is sorted
	 * @param arr the array to be checked
	 * @return true if the array is sorted, false otherwise
	 */
	public static boolean isSorted(int[] arr) {
		for (int i = 0; i < arr.length - 1; i++)
			if (arr[i] > arr[i + 1])
				return false;
		return true;
	}

	
	/** predicate to check if arrayList is sorted.
	 *  Useful for checking ArrayList<Integer> lists returned
	 *  from Quick Sort.
	 * 
	 * @param arr the array to be checked
	 * @return true is the aray is sorted, flalse otherwise
	 */
	public static boolean isSorted(ArrayList<Integer> arr) {
		Iterator i = arr.iterator();
		int val;
		if (i.hasNext())
			val = (int) i.next();
		else
			return true;
		while (i.hasNext()) {
			int nv = (int) i.next();
			if (val > nv)
				return false;
			val = nv;
		}
		return true;
	}

	
	/** Helper printing methods for testing
	 * @param arr the array to print
	 */
	private static void printIntArray(int[] arr) {
		System.out.print("[ ");
		for (Integer i : arr) {
			System.out.print(i + " ");
		}
		System.out.println(" ]");
	}

	private static void printIntArrayList(ArrayList<Integer> arr) {
		System.out.print("[ ");
		for (Integer i : arr) {
			System.out.print(i + " ");
		}
		System.out.println(" ]");
	}

	public static void main(String[] args) {
		// testing part1
		int[] arr1 = { 5, 4, 3, 2, 1 };
		bubbleSort(arr1);
		printIntArray(arr1);

		// testing part2
		ArrayList<Integer> arr2 = new ArrayList<Integer>();
		arr2.add(3);
		arr2.add(1);
		arr2.add(6);
		arr2.add(5);
		ArrayList<Integer> arr2_sorted = quickSort(arr2);
		printIntArrayList(arr2_sorted);
		// {5,4,3,5,1};

	}

}
