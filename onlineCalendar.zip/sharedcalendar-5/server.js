// Import dependencies
const express = require('express');
const bcrypt = require('bcryptjs');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
const db = require('./db'); // Assuming you have a MySQL database connection

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware to parse JSON request bodies
app.use(bodyParser.json());
app.use(express.json());

// Session management middleware
app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Use secure cookies for HTTPS in production
}));

// Serve the login.html page at the root URL
app.get('/', (req, res) => {
    const filePath = path.join(__dirname, 'public', 'LogIn.html');  // Ensure login.html is in the 'public' folder
    console.log("Serving file from:", filePath);
    res.sendFile(filePath);
});

// Serve static files (HTML, CSS, JS) for public access
app.use(express.static(path.join(__dirname, 'public')));

// Handle form submission from Create Account (User Registration)
app.post('/create-account', async (req, res) => {
    const { firstName, lastName, email, password } = req.body;

    // Basic validation
    if (!firstName || !lastName || !email || !password) {
        return res.status(400).json({ success: false, message: 'Please fill out all fields' });
    }

    try {
        // Hash the password before storing it in the database
        const hashedPassword = await bcrypt.hash(password, 10);

        // Insert the user into the database
        const query = `INSERT INTO users (firstname, lastname, email, password) VALUES (?, ?, ?, ?)`;
        db.query(query, [firstName, lastName, email, hashedPassword], (err, result) => {
            if (err) {
                console.error('Error inserting into database:', err);
                return res.status(500).json({ success: false, message: 'Error inserting into database' });
            }
            // Respond with success
            res.status(200).json({ success: true });
        });
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// Handle login requests
app.post('/login', (req, res) => {
    const { email, password } = req.body;

    // Query the database for the user with the given email
    const query = 'SELECT * FROM users WHERE email = ?';
    db.query(query, [email], (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ success: false, message: 'Internal server error' });
        }

        // If user not found
        if (results.length === 0) {
            return res.status(401).json({ success: false, message: 'Invalid credentials' });
        }

        const user = results[0];

        // Compare the provided password with the hashed password in the database
        bcrypt.compare(password, user.password, (err, isMatch) => {
            if (err) {
                console.error(err);
                return res.status(500).json({ success: false, message: 'Internal server error' });
            }

            if (isMatch) {
                // If password matches, set session data
                req.session.user = { id: user.userid, email: user.email, firstname: user.firstname, lastname: user.lastname };
                res.json({ success: true, user: req.session.user });
            } else {
                // Password is incorrect
                res.status(401).json({ success: false, message: 'Invalid credentials' });
            }
        });
    });
});
// Get logged-in user's details (name, email)
app.get('/user', (req, res) => {
    if (req.session.user) {
        // If the user is logged in, send the session user data
        const user = req.session.user;
        res.json({
            name: `${user.firstname} ${user.lastname}`,
            email: user.email
        });
    } else {
        res.status(401).json({ message: 'User not logged in' });
    }
});

// Middleware to check if the user is logged in (used for protected routes)
app.use((req, res, next) => {
    if (req.session.user) {
        next(); // Allow access to protected routes
    } else {
        res.status(401).json({ success: false, message: 'Unauthorized' });
    }
});

// Logout the user and destroy the session
app.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.status(500).send('Could not log out');
        }
        res.redirect('/'); // Redirect to login after logging out
    });
});

// Handle task submission (add a task for a specific user)
app.post('/submit-task', (req, res) => {
    const { taskName, taskDate, startTime, finishTime, taskDesc, allDay } = req.body;

    // Check if the required fields are provided
    if (!taskName || !taskDate || !startTime || !finishTime) {
        return res.status(400).json({ success: false, message: 'Task name, task date and task times are required' });
    }

    
    // Check if the task is all-day
    if (allDay === 1) {
        // If the task is all-day, set start and finish time to full day range
        startTime = '00:00:00'; // Start of the day
        finishTime = '23:59:59'; // End of the day
    }
    // Use the logged-in user's userID from the session
    const userID = req.session.user.id;

    // Assuming a default calendarID for now (You can modify based on your actual calendar structure)
    const calendarID = 1;

    // Insert the task into the database
    const query = `
        INSERT INTO tasks (taskName, description, userID, calendarID, date, startTime, finishTime, allDay) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;
    db.query(query, [taskName, taskDesc, userID, calendarID, taskDate, startTime, finishTime, allDay ? 1 : 0], (err, result) => {
        if (err) {
            console.error('Error inserting task into database:', err);
            return res.status(500).json({ success: false, message: 'Error inserting task into database' });
        }

        // Respond with success
        res.status(200).json({ success: true, message: 'Task added successfully' });
    });
});

// Route to get tasks for a specific user and date
app.get('/tasks', (req, res) => {
    const userID = req.session.user.id;  // Use userID from session
    const taskDate = req.query.date;  // Get the 'date' parameter from the query string

    // Base query to get tasks for the user, including taskID
    let query = `SELECT taskID, taskName, description, date AS taskDate, startTime, finishTime, allDay 
                 FROM tasks WHERE userID = ?`;

    const queryParams = [userID];
    if (taskDate) {
        query += ` AND date = ?`;  // Filter by date if provided
        queryParams.push(taskDate);  // Add the date to the query params
    }

    // Execute the query
    db.query(query, queryParams, (err, tasks) => {
        if (err) {
            console.error('Error retrieving tasks:', err);
            return res.status(500).json({ success: false, message: 'Error fetching tasks from database' });
        }

        // Format the date for each task
        tasks = tasks.map(task => {
            task.taskDate = task.taskDate.toISOString().split('T')[0];  // Format date as YYYY-MM-DD
            return task;
        });

        console.log('Tasks retrieved:', tasks);

        // If no tasks found, return an empty array
        if (tasks.length === 0) {
            return res.status(200).json([]);
        }

        res.status(200).json(tasks);  // Send tasks as response
    });
});

// Route to update a specific task - Used for the editTask button 
app.put('/tasks/:taskId', (req, res) => {
    const taskId = req.params.taskId;
    const { taskName, taskDate, taskTime, taskDesc, allDay } = req.body;

    const query = `
        UPDATE tasks
        SET taskName = ?, description = ?, date = ?, startTime = ?, allDay = ?
        WHERE id = ? AND userID = ?
    `;

    // Create an array of query parameters to be used in a database operation, such as an SQL query
   // Each element corresponds to a parameter that will be passed to the database query.
    const queryParams = [taskName, taskDesc, taskDate, taskTime, allDay ? 1 : 0, taskId, req.session.user.id];
    
    db.query(query, queryParams, (err, result) => {
        if (err) {
            console.error('Error updating task:', err);
            return res.status(500).json({ success: false, message: 'Error updating task' });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({ success: false, message: 'Task not found' });
        }

        res.status(200).json({ success: true, message: 'Task updated successfully' });
    });
});
//  A route to get a specific task by ID - This means that you can have seperate tasks on seperate IDs
app.get('/tasks/:taskId', (req, res) => {
    const taskId = req.params.taskId;

    // Call database query - this requires the session ID
    const query = `SELECT * FROM tasks WHERE id = ? AND userID = ?`;
    const queryParams = [taskId, req.session.user.id];
    
    db.query(query, queryParams, (err, result) => {
        if (err) {
            console.error('Error fetching task:', err);
            // If there is a database error to fetch a task:
            return res.status(500).json({ success: false, message: 'Error fetching task' });
        }

        // If we have no result, then there is no task!
        if (result.length === 0) {
            return res.status(404).json({ success: false, message: 'Task not found' });
        }

        res.status(200).json(result[0]); // Send back the task details
    });
});

// Route to delete a task by ID
app.delete('/tasks/:taskId', (req, res) => {
    const taskId = req.params.taskId;

    // Query to delete the task with the given ID
    const query = `DELETE FROM tasks WHERE taskID = ? AND userID = ?`;
    const queryParams = [taskId, req.session.user.id];

    db.query(query, queryParams, (err, result) => {
        if (err) {
            console.error('Error deleting task:', err);
            return res.status(500).json({ success: false, message: 'Error deleting task' });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({ success: false, message: 'Task not found or unauthorized' });
        }

        res.status(200).json({ success: true, message: 'Task deleted successfully' });
    });
});
//  This starts the server.
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
