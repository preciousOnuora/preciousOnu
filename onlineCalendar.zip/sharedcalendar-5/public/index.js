




// This is out toggleMenu being called.
function toggleMenu() {
  const menu = document.getElementById("menu");
  const header = document.querySelector(".WorkSpaceHeader");
  const calendar = document.getElementById('calendar');

  menu.classList.toggle("show");
  header.classList.toggle("active");
  calendar.classList.toggle('active');
}


document.addEventListener('DOMContentLoaded', () => {
  // Initial calendar setup
  const calendarContainer = document.getElementById('calendar');
  const dateDisplay = document.getElementById('date-display');
  const prevButton = document.getElementById('prev');
  const nextButton = document.getElementById('next');
  let currentDate = new Date();
  let popupContext = null; // Tracks how the popup was opened.

// This is the function to generate a calendar.  
function generateCalendar(month, year) {
    console.log(`Generating calendar for month: ${month + 1}, year: ${year}`);

    const calendarContainer = document.getElementById('calendar');
    if (!calendarContainer) {
        console.error('Calendar container not found!');
        return;
    }
    calendarContainer.innerHTML = ''; // Clear previous calendar content

    const currentDate = new Date(year, month);
    const today = new Date(); // Get today's date
    const options = { month: 'long', year: 'numeric' };

    const dateDisplay = document.getElementById('dateDisplay');
    if (dateDisplay) {
        dateDisplay.textContent = currentDate.toLocaleDateString('en-US', options);
    } else {
        console.error('Date display element not found!');
    }

    const daysOfWeek = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const headerRow = document.createElement('div');
    headerRow.classList.add('row', 'row-cols-7');

    daysOfWeek.forEach(day => {
        const dayCell = document.createElement('div');
        dayCell.classList.add('col', 'day-cell');
        dayCell.textContent = day;
        headerRow.appendChild(dayCell);
    });
    calendarContainer.appendChild(headerRow);

    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const startIndex = (firstDay === 0) ? 6 : firstDay - 1;

    let currentDay = 1;
    let row = document.createElement('div');
    row.classList.add('row', 'row-cols-7');

    // Fill in empty cells before the first day of the month
    for (let i = 0; i < startIndex; i++) {
        const emptyCell = document.createElement('div');
        emptyCell.classList.add('col');
        row.appendChild(emptyCell);
    }

    // Create the day cells for the month
    while (currentDay <= daysInMonth) {
        if (row.children.length === 7) {
            calendarContainer.appendChild(row);
            row = document.createElement('div');
            row.classList.add('row', 'row-cols-7');
        }

        const dayCell = document.createElement('div');
        dayCell.classList.add('col', 'number-cell');
        dayCell.textContent = currentDay;

        const monthString = String(month + 1).padStart(2, '0');
        const dayString = String(currentDay).padStart(2, '0');
        const dateString = `${year}-${monthString}-${dayString}`;

        // Check if this day is today
        if (year === today.getFullYear() && month === today.getMonth() && currentDay === today.getDate()) {
            dayCell.classList.add('today'); // Add the "today" class for today's date
        }

        console.log(`Creating cell for date: ${dateString}`);
        dayCell.setAttribute('data-date', dateString); // Add data-date attribute
        dayCell.addEventListener('click', () => showPopup(dateString)); // Show popup on click

        row.appendChild(dayCell);
        currentDay++;
    }

    // Fill in empty cells after the last day of the month
    const endDay = new Date(year, month, daysInMonth).getDay();
    const endIndex = (endDay === 0) ? 6 : endDay - 1;
    const emptyCellsAfter = 6 - endIndex;

    for (let i = 0; i < emptyCellsAfter; i++) {
        const emptyCell = document.createElement('div');
        emptyCell.classList.add('col');
        row.appendChild(emptyCell);
    }

    if (row.children.length > 0) {
        calendarContainer.appendChild(row);
    }

    console.log('Calendar generation complete.');
}


// This is the function to load tasks from the database into the calendar.
function loadTasks() {
  console.log('Loading tasks for the calendar...');
  fetch('/tasks')
      .then(response => {
          console.log('Response from /tasks:', response);
          if (!response.ok) {
              throw new Error('Failed to fetch tasks');
          }
          return response.json();
      })
      .then(tasks => {
          console.log('Tasks fetched successfully:', tasks);

          // Group tasks by date
          const tasksByDate = tasks.reduce((acc, task) => {
              if (!acc[task.taskDate]) {
                  acc[task.taskDate] = [];
              }
              acc[task.taskDate].push(task);
              return acc;
          }, {});

          // Clear existing tasks and add them
          document.querySelectorAll('.task').forEach(task => task.remove());
          console.log('Cleared previous tasks from calendar.');

         // Create task bars
Object.keys(tasksByDate).forEach(taskDate => {
  const taskDayCell = document.querySelector(`[data-date="${taskDate}"]`);
  if (taskDayCell) {
      tasksByDate[taskDate].forEach((task, index) => {
          const { taskName, description, allDay, taskID } = task;  // Ensure taskID is included

          // Create the task bar
          const taskBar = document.createElement('div');
          taskBar.textContent = taskName;
          taskBar.classList.add('task');
          taskBar.title = description || 'No description provided';
          taskBar.dataset.taskDate = taskDate; // Store the task date in the element
          taskBar.dataset.taskId = taskID; // Store the task ID

          // Position the task bar vertically based on the index (stacked bars)
          taskBar.style.top = `${index * 25}px`;

          // Click event to show tasks in the modal
          taskBar.addEventListener('click', (e) => {
              openTaskModal(taskDate);
          });

          taskDayCell.appendChild(taskBar);
      });
  }
});
      })
      .catch(error => console.error('Error loading tasks:', error));
}


// Open the modal and show tasks for a specific date
function openTaskModal(taskDate) {
  console.log(`Opening task modal for ${taskDate}`);

  // Hide the popup if it's visible
  const popup = document.getElementById('popup');
  if (popup) {
      popup.style.display = 'none';  // Hide the popup completely
  }

  // Update the modal date
  const taskModalDate = document.getElementById('taskModalDate');
  if (taskModalDate) {
      taskModalDate.textContent = `Tasks for ${taskDate}`;
  }

  // Clear the task list before fetching new tasks
  const taskListContainer = document.getElementById('taskList');
  if (taskListContainer) {
      taskListContainer.innerHTML = ''; // Clear previous tasks
  }

  // Fetch tasks for this date
  fetch(`/tasks?date=${taskDate}`)
      .then(response => response.json())
      .then(tasks => {
          // Handle no tasks scenario
          if (tasks.length === 0) {
              const noTasksMessage = document.createElement('div');
              noTasksMessage.classList.add('no-tasks-message');
              noTasksMessage.textContent = 'No tasks scheduled for this date.';
              taskListContainer.appendChild(noTasksMessage);
              return;
          }

          // Display tasks
          tasks.forEach(task => {
              const taskItem = document.createElement('div');
              taskItem.classList.add('task-item');
              taskItem.innerHTML = `
                  <div class="task-header">
                      <strong>${task.taskName}</strong>
                      <span class="task-time">${task.allDay === '1' ? 'All Day' : task.startTime + ' - ' + task.finishTime}</span>
                  </div>
                  <div class="task-actions">
                      <button class="edit-button">Edit</button>
                      <button class="delete-button">Delete</button>
                  </div>
              `;
              taskListContainer.appendChild(taskItem);

              // Attach event listeners for edit and delete buttons dynamically
              const editButton = taskItem.querySelector('.edit-button');
              const deleteButton = taskItem.querySelector('.delete-button');

              // When the edit button is clicked, call the editTask function
              editButton.addEventListener('click', () => {
                  editTask(task); // Pass the whole task object to the edit function
              });

              // When the delete button is clicked, call the deleteTask function
              deleteButton.addEventListener('click', () => {
                  deleteTask(task.taskID); // Pass the task ID directly to deleteTask
              });
          });
      })
      .catch(error => {
          console.error('Error loading tasks for the modal:', error);
      });

  // Show the modal
  const taskModal = document.getElementById('taskModal');
  if (taskModal) {
      taskModal.style.display = 'flex';
  }
}


document.querySelector('.close-btn').addEventListener('click', () => {
  console.log("Closing popup");

  // Hide the popup menu
  document.getElementById('popup').style.display = 'none';

  if (popupContext === 'modal') {
      // Show the modal menu if the popup was opened from the modal
      console.log("Returning to modal menu");
      document.getElementById('taskModal').style.display = 'flex';
  } else {
      // Do nothing if the popup was opened from a calendar cell
      console.log("Popup closed, not returning to modal menu");
  }

  // Reset popupContext for safety
  popupContext = null;
});

document.getElementById('closeModalBtn').addEventListener('click', () => {
  console.log("Closing modal");

  // Hides the modal menu
  document.getElementById('taskModal').style.display = 'none';
});

// This function will be called when a calendar cell is clicked - Shows all the dates.
function showTasksForDate(date) {
  // Get the modal elements
  const modal = document.getElementById('taskModal');
  const modalDateDisplay = document.getElementById('modal-date');
  const taskList = document.getElementById('task-list');
  const addTaskBtn = document.getElementById('addTaskBtn');

  // Update the modal with the clicked date
  modalDateDisplay.textContent = date;

  // Clear the task list (in case it has any previous content)
  taskList.innerHTML = '';

  // Fetch the tasks for this date from the server
  fetch(`/tasks?date=${date}`)
    .then(response => response.json())
    .then(tasks => {
      // Populate the task list
      tasks.forEach(task => {
        const taskItem = document.createElement('li');
        taskItem.textContent = task.taskName;  // Display task name

        // You can add more info here, like task description or time

        // Append each task to the task list in the modal
        taskList.appendChild(taskItem);
      });
    })
    .catch(err => {
      console.error('Error fetching tasks:', err);
    });

  // Show the modal
  modal.style.display = 'block';

  // Add event listener to close the modal menu
  const closeBtn = document.querySelector('.close-btn');
  closeBtn.addEventListener('click', () => {
    modal.style.display = 'none';
  });

  // Add event listener to the Add Task button
  addTaskBtn.addEventListener('click', () => {
    // Implement the functionality to add a new task here
    console.log('Add task clicked for date:', date);
    // You can call your existing code to show the add task popup
  });
}

// Add event listener to each day cell
document.querySelectorAll('.number-cell').forEach(cell => {
  cell.addEventListener('click', () => {
    const date = cell.getAttribute('data-date');  // Get the date from the clicked cell
    showTasksForDate(date);  // Call the function to show tasks for that date
  });
});
  // Add task to the calendar when the user submits the form
  document.getElementById('task-form').addEventListener('submit', (event) => {
    event.preventDefault();  // Prevent form submission (default action)

    const formData = {
      "taskName": document.getElementById("task-name").value,
      "taskDate": document.getElementById("task-date").value,
      "startTime": document.getElementById("start-time").value, // Updated to match backend
      "finishTime": document.getElementById("finish-time").value, // Updated to match backend
      "taskDesc": document.getElementById("task-desc").value,
      "allDay": document.getElementById("all-day").checked ? '1' : '0' // checkbox logic
    };
    
    // Log the form data for debugging
    console.log('Form Data:', formData);
    // Handle checkbox value
    // Send task data to the server to be saved in the database
    fetch('/submit-task', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(formData),
    })
      .then(response => response.text())  // Assuming the server returns a simple success message
      .then(message => {
        alert(message);  // Show success message (e.g., 'Task added successfully')
        loadTasks();  // Reload the tasks and update the calendar with the new task
        hidePopup();  // Optionally hide a popup if you're using one to add the task
      })
      .catch(error => console.error('Error submitting task:', error));
  });
  // Show the pop-up when clicking a calendar date
  function showPopup(date) {
    const popup = document.getElementById('popup');
    const closeBtns = document.querySelector('.close-btns');
    const taskDateInput = document.getElementById('task-date');
    const taskModal = document.getElementById('taskModal');

    taskDateInput.value = date;  // Set the task date field to the selected date

    // If the modal display is open then the popup menu will not open
    if(taskModal.style.display === 'flex'){
      console.log("Task modal is open. Popup will not appear.")
      return;
    }
    popup.style.display = 'block';

    closeBtns.addEventListener('click', () => {
      popup.style.display = 'none';
    });
  }

  // Hide the popup
  function hidePopup() {
    // Hide the popup
    const popup = document.getElementById('popup');
    popup.style.display = 'none';
    
    // If we opened the popup from a task, we go back to the task modal
    if (popupOpenedFromTask) {
        document.getElementById('taskModal').style.display = 'flex';
    }
}

// Function to show the tasks in the modal menu.
  function showMyTasks() {
    const tasksPopup = document.getElementById('tasksPopup');
    const close = document.getElementById('closePopup');
    
    tasksPopup.style.display = 'block'; // Show the popup
    
    // Close the popup when the close button is clicked
    close.addEventListener('click', () => {
      tasksPopup.style.display = 'none'; // Hide the popup
    });
  }
  
  // Hide the 'My Tasks' popup
  function hideMyTasks() {
    const tasksPopup = document.getElementById('tasksPopup');
    tasksPopup.style.display = 'none'; // Hide the popup
  }
  // Open the task popup for adding new tasks (this function should work for new task creation)
  document.getElementById('addNewTaskBtn').addEventListener('click', () => {
    // Clear any previous task data and reset the form
    document.getElementById('task-name').value = '';
    document.getElementById('task-date').value = '';
    document.getElementById('start-time').value = '';
    document.getElementById('finish-time').value = '';
    document.getElementById('task-desc').value = '';
    document.getElementById('all-day').checked = false;
  
    // Set context to 'modal' (to indicate it's for adding a new task)
    popupContext = 'modal';
  
    // Show the popup for a new task
    document.getElementById('popup').style.display = 'block';
  });
  
  function editTask(taskId) {
    console.log("Editing task with ID:", taskId);  // Log the taskId to verify it's correct
  
    // Fetch the task details from the server
    fetch(`/tasks/${taskId}`)
      .then(response => response.json())
      .then(task => {
        if (task) {
          document.getElementById('task-name').value = task.taskName || '';
          document.getElementById('task-date').value = task.taskDate || '';
          document.getElementById('start-time').value = task.startTime || '';
          document.getElementById('finish-time').value = task.finishTime || '';
          document.getElementById('task-desc').value = task.description || '';
          document.getElementById('all-day').checked = task.allDay === '1';
  
          // Set context to edit task
          popupContext = 'edit';
  
          // Check if the submit button exists before setting onclick
          const submitButton = document.getElementById('submit-task-btn');
          console.log("Submit button:", submitButton);  // Log the button element
          if (submitButton) {
            // Set the submit button to call the updateTask function when clicked
            submitButton.onclick = function() {
              updateTask(task.taskID);  // Pass the correct taskID to update
            };
          } else {
            console.error("Submit button not found");
          }
  
          // Show the popup
          const popup = document.getElementById('popup');
          if (popup) {
            popup.style.display = 'block';
          }
  
          document.getElementById('addEditModalTitle').innerText = 'Edit Task';  // Optional: Change title
        }
      })
      .catch(error => {
        console.error('Error fetching task:', error);
      });
  }

// Updates the task in the database
function updateTask(taskId) {
  const taskName = document.getElementById('task-name').value;
  const taskDate = document.getElementById('task-date').value;
  const startTime = document.getElementById('start-time').value;
  const finishTime = document.getElementById('finish-time').value;
  const taskDesc = document.getElementById('task-desc').value;
  const allDay = document.getElementById('all-day').checked;

  // Send the updated task data to the server
  fetch(`/tasks/${taskId}`, {
    method: 'PUT',
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify({ taskName, taskDate, startTime, finishTime, taskDesc, allDay })
  })
  .then(response => response.json())
  .then(data => {
      if (data.success) {
          console.log('Task updated successfully');
          location.reload(); // Refreshes the task list or update dynamically as needed
      } else {
          console.error('Error updating task:', data.message);
      }
  })
  .catch(error => {
      console.error('Error:', error);
  });
}

// Function to delete a task from the database.
function deleteTask(taskId) {
  const confirmation = confirm("Are you sure you want to delete this task?");
  if (confirmation) {
      fetch(`/tasks/${taskId}`, {
          method: 'DELETE',
      })
      .then(response => response.json())
      .then(data => {
          if (data.success) {
              console.log('Task deleted successfully');
              // Remove the task from the DOM
              const taskElement = document.getElementById(`task-${taskId}`);
              if (taskElement) {
                  taskElement.remove();
              }
          } else {
              console.error('Error deleting task:', data.message);
          }
      })
      .catch(error => {
          console.error('Error deleting task:', error);
      });
  }
}
// Function to show the account popup
function showAccount() {
  const accountPopup = document.getElementById('accountPopup');
  const close = document.getElementById('closeAccount');

  // Fetch the logged-in user's data from the server
  fetch('/user')
    .then(response => {
      if (!response.ok) {
        throw new Error('User not logged in');
      }
      return response.json();
    })
    .then(user => {
      // Populate the account popup with the user data
      document.getElementById('accountName').textContent = user.name;
      document.getElementById('accountEmail').textContent = user.email;

      // Show the popup
      accountPopup.style.display = 'block';

      // Close the popup when the close button is clicked
      close.addEventListener('click', () => {
        accountPopup.style.display = 'none'; // Hide the popup
      });
    })
    .catch(error => {
      console.error('Error:', error);
      alert('You must be logged in to view account details.');
    });
}

// Function to hide the account popup
function hideAccount() {
  const accountPopup = document.getElementById('accountPopup');
  accountPopup.style.display = 'none'; // Hide the popup
}

// Ensure the popup is hidden by default when the page loads
window.addEventListener('load', () => {
  hideAccount(); // Hide the popup when the page loads
});

// Ensure the popup appears when 'account' is clicked
const myaccount = document.getElementById('myAccount');
myaccount.addEventListener('click', (event) => {
  event.preventDefault(); // Prevent default link behavior (navigation)
  showAccount(); // Show the popup
});


// Ensure the popup is hidden by default (CSS should handle it)
window.addEventListener('load', () => {
    hideMyTasks(); 
});

// Ensure the popup appears when 'My Tasks' is clicked
const myTasks = document.getElementById('myTasks');
myTasks.addEventListener('click', (event) => {
    event.preventDefault(); // Prevent default link behavior (navigation)
    showMyTasks(); // Show the popup
});

  // Navigation buttons for moving between months
  prevButton.addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() - 1);
    generateCalendar(currentDate.getMonth(), currentDate.getFullYear());
    loadTasks();  // Reload tasks for the new month
  });

  nextButton.addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() + 1);
    generateCalendar(currentDate.getMonth(), currentDate.getFullYear());
    loadTasks();  // Reload tasks for the new month
  });

  // Initial render
  generateCalendar(currentDate.getMonth(), currentDate.getFullYear());
  loadTasks();  // Load tasks after the initial calendar render
});

