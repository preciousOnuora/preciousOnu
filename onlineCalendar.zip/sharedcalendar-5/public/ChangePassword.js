const popup = document.getElementById('popup');
const closeButton = document.querySelector('.close-btn');
const emailInput = document.getElementById('email-input');
const submitBtn = document.getElementById("email-btn");
const emailError = document.getElementById("email-error");

// Function to validate the email format using a regular expression (regex)
function validateEmail(email) {
    const regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return regex.test(email);
}

// Function to enable/disable the submit button based on email validity
function toggleSubmitButton() {
    // Check if the email input is valid
    
    if (validateEmail(emailInput.value)) {
        // Enable the button if the email is valid
        submitBtn.disabled = false;
        emailError.style.display = 'none'; // Hide error if email is valid
    } else {
        // Disable the button if the email is invalid
        submitBtn.disabled = true;
        emailError.style.display = 'block'; // SHow error if email is invalid
    }
}

// Add an event listener to the email input field to check on each input change
emailInput.addEventListener('input', toggleSubmitButton);


function showDiv() {
    document.getElementById('popup').style.display = "block";
    closeButton.addEventListener('click', hidePopup);
 }

// Function to hide the pop-up
function hidePopup() {
    popup.style.display = 'none'; // Hide the pop-up
}

// Get references to the form elements
const form = document.getElementById('password-form');
const errorMessage = document.getElementById('error-msg');
const pwbtn = document.getElementById('con-pw-btn');

function displayError() {
    var errorMsg = document.getElementById("pw-error");
    
    errorMsg.style.display = 'block';
  }

    const pwError = document.getElementById("pw-error");
    
function checkValues() {
    // Get the values of the input fields
    var newPW = document.getElementById("pw-new").value;
    var confNew = document.getElementById("pw-con").value;
    
    // Get the submit button
    var submitButton = document.getElementById("pwConfirmBtn");

  
    // If the values are the same and not empty, enable the submit button
    if (newPW === confNew && newPW !== "") {
        submitButton.disabled = false;
        pwError.style.display = 'none';
    } else {
      submitButton.disabled = true;
      pwError.style.display = 'block';
    }
  }

    var form1 = document.getElementById("form1");
    var form2 = document.getElementById("form2");
    var form3 = document.getElementById("form3");
    var securityForm = document.getElementById("security-form");

function showForm1() {
    form1.style.display = 'block';
    securityForm.style.display = 'none';
}

function showForm2() {
    form2.style.display = 'block';
    securityForm.style.display = 'none';
}

function showForm3() {
    form3.style.display = 'block';
    securityForm.style.display = 'none';
}
// This whole chunk of code is very poorly efficient code, as it basically repeats for all three functions, ran out of time, sorry!
      // Function to show the password change form when the security question form is submitted
      function showPWForm1() {
        // Hide the first form
        document.getElementById("form1").style.display = 'none';
        
        // Show the second form
        document.getElementById('password-form').style.display = 'block';
    }
    

      // Function to show the password change form when the security question form is submitted
      function showPWForm2() {
        // Hide the first form 
        document.getElementById("form2").style.display = 'none';
        
        // Show the second form
        document.getElementById('password-form').style.display = 'block';
    }


      // Function to show the password change form when the security question form is submitted
      function showPWForm3() {
        // Hide the first form
        document.getElementById("form3").style.display = 'none';
        
        // Show the second form
        document.getElementById('password-form').style.display = 'block';
    }