document.getElementById('loginForm').addEventListener('submit', async function(event) {
    event.preventDefault(); // Prevent default form submission

    const email = document.querySelector("input[name='email']").value;
    const password = document.querySelector("input[name='password']").value;

    // Sends  the login data to the server
    const response = await fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
    });

    const data = await response.json();

    // If we can fetch the email and password, then we load the calendar page.
    if (data.success) {
        alert('Login successful!');
        window.location.href = '/index.html'; // Redirect upon success
    } else {
        // If anything goes wrong, we return a login failed message.
        alert(data.message || 'Login failed');
    }
});
