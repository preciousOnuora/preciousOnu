// db.js

const mysql = require('mysql2');

// Create a MySQL database connection
const db = mysql.createConnection({
    host: 'localhost',    // Database host
    user: 'root',         // Database username
    password: 'C780qpJA!REM',      // Database password - Only manually will this password be required.
    database: 'plannerapp' // Database name
});

// Connect to the database
db.connect((err) => {
    if (err) {
        console.error('Error connecting to the MySQL database:', err);
        throw err; // Exit the application if the connection fails
    }
    console.log('Connected to the MySQL database.');
});

// Export the database connection
module.exports = db;
