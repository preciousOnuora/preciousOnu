Working SQL for database (this is the where i got the variable names from when updating the php files -catherine) http://localhost/phpmyadmin, use this to run the our website http://localhost/sharedcalendar/CreateAccount/CreateAccount.html (change the path for different pages)

CREATE DATABASE sharedcalendar; (has to be one word)

CREATE TABLE Users (
    userID INT PRIMARY KEY AUTO_INCREMENT,
    firstName VARCHAR(50) NOT NULL,
    lastName VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE Calendar (
    calendarID INT PRIMARY KEY AUTO_INCREMENT,
    calendarType VARCHAR(50) NOT NULL,
    calendarName VARCHAR(100) NOT NULL,
    shareLink VARCHAR(255)
);

CREATE TABLE Tasks (
    taskID INT PRIMARY KEY AUTO_INCREMENT,
    taskName VARCHAR(100) NOT NULL,
    description TEXT,
    date DATE NOT NULL,
    time TIME,
    startTime TIME,
    finishTime TIME,
    allDay BOOLEAN NOT NULL,
    userID INT NOT NULL,
    calendarID INT NOT NULL,
    FOREIGN KEY (userID) REFERENCES Users(userID),
    FOREIGN KEY (calendarID) REFERENCES Calendar(calendarID)
);

for the php to run all files must be in the C:\xampp\htdocs file on ur computer. 
to test that it is working run;

file:///C:/xampp/htdocs/sharedcalendar/CreateAccount/CreateAccount.html (example for create account only)

For installing Express and node.js on ur computer 
in ur terminal put npm init and then npm install express


THINGS NEEDED DONE

-make sure email can only be used once in the sql database, an js error should display if tried to use existing email in the database

-Back end for log in, when inccorect password or email entered show a more user friendly display 

-Back end for change password

-The front end for the menu 

- css made more like the figma for index page

- tasks become visible on the calendar 

- back end for showing old and completed tasks 

